var dir_dadcfc53e6a1230ff2f48f6f7265c16c =
[
    [ "Exception.php", "_adapter_2_file_transfer_2_exception_8php.html", [
      [ "TeamSpeak3_Adapter_FileTransfer_Exception", "class_team_speak3___adapter___file_transfer___exception.html", "class_team_speak3___adapter___file_transfer___exception" ]
    ] ]
];