var class_team_speak3___adapter___server_query___exception =
[
    [ "prepareCustomMessage", "class_team_speak3___adapter___server_query___exception.html#a3bfcdf7b85a393b7a8b05b048ae3279c", null ],
    [ "getSender", "class_team_speak3___adapter___server_query___exception.html#ae7d4b369dd11d3cf56d120acae0cf1db", null ]
];