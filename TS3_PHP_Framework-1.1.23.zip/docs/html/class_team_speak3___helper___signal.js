var class_team_speak3___helper___signal =
[
    [ "emit", "class_team_speak3___helper___signal.html#a26e8fc61637d146b0347b7c9e09587ab", null ],
    [ "getCallbackHash", "class_team_speak3___helper___signal.html#ada301980bc0f9b8f310e8656972b6a35", null ],
    [ "subscribe", "class_team_speak3___helper___signal.html#a058ad6105e05a7b8c620b9446c545984", null ],
    [ "unsubscribe", "class_team_speak3___helper___signal.html#a74e337835a70aa10894202bb43d8c30b", null ],
    [ "getSignals", "class_team_speak3___helper___signal.html#aa690a091efef853c4a47d7b7e7363c03", null ],
    [ "hasHandlers", "class_team_speak3___helper___signal.html#a840339183812e5e51d9c3b1beb9d1fd3", null ],
    [ "getHandlers", "class_team_speak3___helper___signal.html#af414b1e8d18081c374a852c12c0b5cb6", null ],
    [ "clearHandlers", "class_team_speak3___helper___signal.html#a8610e4f73d3f5b564edd1dfa81f1ac28", null ],
    [ "$sigslots", "class_team_speak3___helper___signal.html#a11b8fbdbfd24afb14ac47262aba4c2c6", null ]
];