var searchData=
[
  ['client_5ftype_5fregular',['CLIENT_TYPE_REGULAR',['../class_team_speak3.html#ae2f58969a8868c4793c485d63e6e7f05',1,'TeamSpeak3']]],
  ['client_5ftype_5fserverquery',['CLIENT_TYPE_SERVERQUERY',['../class_team_speak3.html#a3c3b0109548e9a41717d64db57f54b6a',1,'TeamSpeak3']]],
  ['codec_5fcelt_5fmono',['CODEC_CELT_MONO',['../class_team_speak3.html#a8706d107a6d0bd56003436cf91931015',1,'TeamSpeak3']]],
  ['codec_5fcrypt_5fdisabled',['CODEC_CRYPT_DISABLED',['../class_team_speak3.html#a204ba3447155504ad79532e02b0047c8',1,'TeamSpeak3']]],
  ['codec_5fcrypt_5fenabled',['CODEC_CRYPT_ENABLED',['../class_team_speak3.html#af264159fd49c066ad3e88b475a168e45',1,'TeamSpeak3']]],
  ['codec_5fcrypt_5findividual',['CODEC_CRYPT_INDIVIDUAL',['../class_team_speak3.html#af4beb7ff503847abc4d8f00fa4a14929',1,'TeamSpeak3']]],
  ['codec_5fopus_5fmusic',['CODEC_OPUS_MUSIC',['../class_team_speak3.html#ad86387b6183780d2af6a1918552fc00b',1,'TeamSpeak3']]],
  ['codec_5fopus_5fvoice',['CODEC_OPUS_VOICE',['../class_team_speak3.html#ac8a12a60994f2949c63e21d8915c8afa',1,'TeamSpeak3']]],
  ['codec_5fspeex_5fnarrowband',['CODEC_SPEEX_NARROWBAND',['../class_team_speak3.html#a73cb8b928682f11db10d5f4bf92c579d',1,'TeamSpeak3']]],
  ['codec_5fspeex_5fultrawideband',['CODEC_SPEEX_ULTRAWIDEBAND',['../class_team_speak3.html#ab1b79661570e52e80cb9382286c3f0a6',1,'TeamSpeak3']]],
  ['codec_5fspeex_5fwideband',['CODEC_SPEEX_WIDEBAND',['../class_team_speak3.html#a7e144effeaf513a660467a0dadd1ae97',1,'TeamSpeak3']]]
];
