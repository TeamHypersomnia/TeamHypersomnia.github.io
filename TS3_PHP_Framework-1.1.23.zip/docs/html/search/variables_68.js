var searchData=
[
  ['hostbanner_5fignore_5faspect',['HOSTBANNER_IGNORE_ASPECT',['../class_team_speak3.html#a0948f6a231bacd72d3455adc3314aadb',1,'TeamSpeak3']]],
  ['hostbanner_5fkeep_5faspect',['HOSTBANNER_KEEP_ASPECT',['../class_team_speak3.html#aa9e2a430fd552f4a0c3dec0855a4f8ad',1,'TeamSpeak3']]],
  ['hostbanner_5fno_5fadjust',['HOSTBANNER_NO_ADJUST',['../class_team_speak3.html#a5a13321bcb3eff4b51cbe56eb342b701',1,'TeamSpeak3']]],
  ['hostmsg_5flog',['HOSTMSG_LOG',['../class_team_speak3.html#a6c155661d55cd61ef79b1fd6413e5880',1,'TeamSpeak3']]],
  ['hostmsg_5fmodal',['HOSTMSG_MODAL',['../class_team_speak3.html#a7d044183051509b77831a5546748245e',1,'TeamSpeak3']]],
  ['hostmsg_5fmodalquit',['HOSTMSG_MODALQUIT',['../class_team_speak3.html#ad1956014c2a37cf8883bc6e845991597',1,'TeamSpeak3']]],
  ['hostmsg_5fnone',['HOSTMSG_NONE',['../class_team_speak3.html#a4350e9a5261f832d44d3b416d5bdcb50',1,'TeamSpeak3']]]
];
