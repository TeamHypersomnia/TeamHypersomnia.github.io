var searchData=
[
  ['kick_5fchannel',['KICK_CHANNEL',['../class_team_speak3.html#ab6a4d55688e33c16004508fff14c81da',1,'TeamSpeak3']]],
  ['kick_5fserver',['KICK_SERVER',['../class_team_speak3.html#ae9df1f0980b1d3e9638b3a8084cc5234',1,'TeamSpeak3']]]
];
