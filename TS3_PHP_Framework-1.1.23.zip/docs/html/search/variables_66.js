var searchData=
[
  ['file_5ftype_5fdirectory',['FILE_TYPE_DIRECTORY',['../class_team_speak3.html#a0dfea6a5fe76141895e0f2900e8e4e52',1,'TeamSpeak3']]],
  ['file_5ftype_5fregular',['FILE_TYPE_REGULAR',['../class_team_speak3.html#aec926b29e75ca080eb7fb8fbf69f9ab9',1,'TeamSpeak3']]]
];
