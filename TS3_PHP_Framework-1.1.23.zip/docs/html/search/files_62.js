var searchData=
[
  ['blacklist_2ephp',['Blacklist.php',['../_blacklist_8php.html',1,'']]]
];
