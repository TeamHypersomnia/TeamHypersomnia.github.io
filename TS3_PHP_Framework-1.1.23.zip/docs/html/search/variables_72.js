var searchData=
[
  ['ready',['READY',['../class_team_speak3.html#ae31cefccb5993d1b5fa8fa9f52180bfe',1,'TeamSpeak3']]],
  ['reason_5fchannel_5fedit',['REASON_CHANNEL_EDIT',['../class_team_speak3.html#a47403f14dad07252a387b8cc7e5d816f',1,'TeamSpeak3']]],
  ['reason_5fchannel_5fkick',['REASON_CHANNEL_KICK',['../class_team_speak3.html#a3c394288b3b45df4a039127d1e119517',1,'TeamSpeak3']]],
  ['reason_5fchannel_5fupdate',['REASON_CHANNEL_UPDATE',['../class_team_speak3.html#a7d82c5b03e862e2f53313363e1423535',1,'TeamSpeak3']]],
  ['reason_5fdisconnect',['REASON_DISCONNECT',['../class_team_speak3.html#ae10cf1e6e6a365cf61eb7e38f6a2315b',1,'TeamSpeak3']]],
  ['reason_5fdisconnect_5fshutdown',['REASON_DISCONNECT_SHUTDOWN',['../class_team_speak3.html#a9dcf492812b8b16ffbebcd05ffa1e6bf',1,'TeamSpeak3']]],
  ['reason_5fmove',['REASON_MOVE',['../class_team_speak3.html#aad9bd5c1089efa20620cab286052b0f3',1,'TeamSpeak3']]],
  ['reason_5fnone',['REASON_NONE',['../class_team_speak3.html#afb77656b36c45073e770f13bf0a90e5d',1,'TeamSpeak3']]],
  ['reason_5fserver_5fban',['REASON_SERVER_BAN',['../class_team_speak3.html#ad9dc7ed023c1a9be4504ba894a63bee1',1,'TeamSpeak3']]],
  ['reason_5fserver_5fkick',['REASON_SERVER_KICK',['../class_team_speak3.html#a931e59afb66273ee4255e43676812726',1,'TeamSpeak3']]],
  ['reason_5fserver_5fstop',['REASON_SERVER_STOP',['../class_team_speak3.html#ac48ef3e11414170eecffcd252a637062',1,'TeamSpeak3']]],
  ['reason_5fsubscription',['REASON_SUBSCRIPTION',['../class_team_speak3.html#a328b7a4eeed0ecd61865be986aa79f9c',1,'TeamSpeak3']]],
  ['reason_5ftimeout',['REASON_TIMEOUT',['../class_team_speak3.html#aea8db94828ad856d0a207d228145e41a',1,'TeamSpeak3']]]
];
