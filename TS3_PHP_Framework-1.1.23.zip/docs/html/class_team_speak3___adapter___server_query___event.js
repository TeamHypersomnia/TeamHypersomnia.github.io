var class_team_speak3___adapter___server_query___event =
[
    [ "__construct", "class_team_speak3___adapter___server_query___event.html#ab847f72f60d9a87e577455a326b97d35", null ],
    [ "getType", "class_team_speak3___adapter___server_query___event.html#aba87307c13aaa64c3c91e4fa398517ef", null ],
    [ "getData", "class_team_speak3___adapter___server_query___event.html#a476acf6ce132b0a3d0b4fc9b22e7405e", null ],
    [ "getMessage", "class_team_speak3___adapter___server_query___event.html#aec6954f96cbc4a229348ae31f9b289e7", null ],
    [ "offsetExists", "class_team_speak3___adapter___server_query___event.html#a57ae033a9a2926762f557fb8705d8a15", null ],
    [ "offsetGet", "class_team_speak3___adapter___server_query___event.html#a6c3c6a21f1f6dd8e594669868c310c81", null ],
    [ "offsetSet", "class_team_speak3___adapter___server_query___event.html#a9eb8d547545fa1e17f70c8ee5ba33a9c", null ],
    [ "offsetUnset", "class_team_speak3___adapter___server_query___event.html#a41ef812dbfe2d1e1b517bd123fc960f6", null ],
    [ "__get", "class_team_speak3___adapter___server_query___event.html#a496f7adbe81710f97848608dc3b29265", null ],
    [ "__set", "class_team_speak3___adapter___server_query___event.html#a8c466fb68578cc95504035aae3785759", null ],
    [ "$type", "class_team_speak3___adapter___server_query___event.html#ae37c57dcc407345531912b3687ffdee9", null ],
    [ "$data", "class_team_speak3___adapter___server_query___event.html#a57104b2b838c8a4ba3b7b65b9d91205b", null ],
    [ "$mesg", "class_team_speak3___adapter___server_query___event.html#a5486d8a3491e6096e4fdfd39ea2149d6", null ]
];