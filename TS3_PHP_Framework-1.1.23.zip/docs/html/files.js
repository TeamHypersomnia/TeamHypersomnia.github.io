var files =
[
    [ "TeamSpeak3", "dir_8c6eb96e4942c21c15d2738fe9c923ec.html", "dir_8c6eb96e4942c21c15d2738fe9c923ec" ]
];