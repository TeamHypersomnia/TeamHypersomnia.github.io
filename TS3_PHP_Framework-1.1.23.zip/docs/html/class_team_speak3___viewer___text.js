var class_team_speak3___viewer___text =
[
    [ "fetchObject", "class_team_speak3___viewer___text.html#a8fb29a4ed7e5a605bd59bed82fd912bc", null ],
    [ "getPrefix", "class_team_speak3___viewer___text.html#acd7d9ebbae3700e38b0bcb6767728936", null ],
    [ "getCorpusIcon", "class_team_speak3___viewer___text.html#a7bf9b2137c14dad13c8fd2e2df33615c", null ],
    [ "getCorpusName", "class_team_speak3___viewer___text.html#a8d6fcf3812bf72c81214263da3e6f555", null ],
    [ "$pattern", "class_team_speak3___viewer___text.html#aa39cd6d4d771d9c4d94e368e1b548405", null ]
];