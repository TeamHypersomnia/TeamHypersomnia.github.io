var dir_3d7cd49b95def433e02a0e6f52be25f0 =
[
    [ "Abstract.php", "_node_2_abstract_8php.html", [
      [ "TeamSpeak3_Node_Abstract", "class_team_speak3___node___abstract.html", "class_team_speak3___node___abstract" ]
    ] ],
    [ "Channel.php", "_channel_8php.html", [
      [ "TeamSpeak3_Node_Channel", "class_team_speak3___node___channel.html", "class_team_speak3___node___channel" ]
    ] ],
    [ "Channelgroup.php", "_channelgroup_8php.html", [
      [ "TeamSpeak3_Node_Channelgroup", "class_team_speak3___node___channelgroup.html", "class_team_speak3___node___channelgroup" ]
    ] ],
    [ "Client.php", "_client_8php.html", [
      [ "TeamSpeak3_Node_Client", "class_team_speak3___node___client.html", "class_team_speak3___node___client" ]
    ] ],
    [ "Exception.php", "_node_2_exception_8php.html", [
      [ "TeamSpeak3_Node_Exception", "class_team_speak3___node___exception.html", "class_team_speak3___node___exception" ]
    ] ],
    [ "Host.php", "_host_8php.html", [
      [ "TeamSpeak3_Node_Host", "class_team_speak3___node___host.html", "class_team_speak3___node___host" ]
    ] ],
    [ "Server.php", "_server_8php.html", [
      [ "TeamSpeak3_Node_Server", "class_team_speak3___node___server.html", "class_team_speak3___node___server" ]
    ] ],
    [ "Servergroup.php", "_servergroup_8php.html", [
      [ "TeamSpeak3_Node_Servergroup", "class_team_speak3___node___servergroup.html", "class_team_speak3___node___servergroup" ]
    ] ]
];