var interface_team_speak3___viewer___interface =
[
    [ "fetchObject", "interface_team_speak3___viewer___interface.html#ad06c809a76558069871ba9aa16f66e79", null ]
];